# Imports
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from qiskit import QuantumCircuit, Aer, transpile
from qiskit.circuit import ParameterVector
from qiskit.utils import QuantumInstance
from qiskit_machine_learning.connectors import TorchConnector
from qiskit_machine_learning.neural_networks import EstimatorQNN
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen

# Load dataset
df = pd.read_csv("/mnt/data/b32fcee0-4654-4ef9-b75e-b96a0de8ad18.csv").dropna()
df = df[df['smiles'].apply(lambda x: isinstance(x, str) and len(x) < 200)]

# Feature extraction
def featurize(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return [
            Descriptors.MolWt(mol),
            Descriptors.TPSA(mol),
            Descriptors.NumHDonors(mol),
            Descriptors.NumHAcceptors(mol),
            Descriptors.FpDensityMorgan1(mol),
        ]
    return [0] * 5

features = df['smiles'].apply(featurize).tolist()
X = np.array(features)

# Set LogP as target property
df['property'] = df['smiles'].apply(lambda x: Crippen.MolLogP(Chem.MolFromSmiles(x)))
y = df['property'].astype(float).values

# Normalize and split
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2)

# Convert to PyTorch tensors
X_train_t = torch.tensor(X_train, dtype=torch.float32)
X_test_t = torch.tensor(X_test, dtype=torch.float32)
y_train_t = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)
y_test_t = torch.tensor(y_test, dtype=torch.float32).unsqueeze(1)

# Quantum circuit (5 qubits, no classical input needed for Qiskit Estimator)
num_qubits = 5
params = ParameterVector('theta', length=num_qubits * 3)
qc = QuantumCircuit(num_qubits)
for i in range(num_qubits):
    qc.ry(params[i], i)
    qc.rz(params[i + num_qubits], i)
    qc.ry(params[i + 2 * num_qubits - 1], i)
for i in range(num_qubits - 1):
    qc.cx(i, i + 1)

# Estimator QNN
qi = QuantumInstance(Aer.get_backend('aer_simulator_statevector'))
qnn = EstimatorQNN(circuit=qc, input_params=[], weight_params=params, quantum_instance=qi)
quantum_model = TorchConnector(qnn)

# Classical neural net block
class ClassicalExtractor(nn.Module):
    def __init__(self, input_dim=5, output_dim=5):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.ReLU(),
            nn.Linear(16, output_dim)
        )
    def forward(self, x):
        return self.fc(x)

# Final hybrid model
class QCMPNet(nn.Module):
    def __init__(self, quantum_model, classical_dim=5, fusion_dim=5):
        super().__init__()
        self.classical_net = ClassicalExtractor()
        self.quantum_model = quantum_model
        self.alpha = nn.Parameter(torch.tensor(0.5))  # Fusion weight
        self.fc_out = nn.Linear(fusion_dim, 1)

    def forward(self, x):
        c_feat = self.classical_net(x)
        q_feat = self.quantum_model(torch.rand(x.size(0), 0))  # dummy input
        fused = self.alpha * q_feat + (1 - self.alpha) * c_feat
        return self.fc_out(fused)

# Train setup
model = QCMPNet(quantum_model)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# Training loop
for epoch in range(50):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train_t)
    loss = criterion(outputs, y_train_t)
    loss.backward()
    optimizer.step()
    if epoch % 5 == 0:
        print(f"Epoch {epoch}: Train Loss = {loss.item():.4f}")

# Evaluation
model.eval()
with torch.no_grad():
    preds = model(X_test_t)
    test_loss = criterion(preds, y_test_t)
    print(f"\nFinal Test MSE (LogP): {test_loss.item():.4f}")
